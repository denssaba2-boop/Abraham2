// sw.js — ቀላል Service Worker ለ ቅዱስ ሩፋኤል ዕድር PWA
// CACHE_VERSION ቁጥር ከ index.html ውስጥ ካለው APP_VERSION ጋር በየ deploy ጊዜ አብሮ መቀየር ያስፈልጋል።
const CACHE_VERSION = "2.46.19";
const CACHE_NAME = "edir-cache-v" + CACHE_VERSION;

const PRECACHE_URLS = [
  "./index.html",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.jpg",
  "./logo.jpg"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  const isHTML = req.mode === "navigate" || url.pathname.endsWith("index.html") || url.pathname === "/";

  if (isHTML) {
    // Network-first ለ index.html — ስለዚህ ዘመናዊ ስሪት ካለ ሁልጊዜ ቅድሚያ ይሰጠዋል፣
    // ኢንተርኔት ከሌለ ግን ካሽ ላይ ወደተቀመጠው ቅጂ ይመለሳል።
    event.respondWith(
      fetch(req)
        .then((res) => {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          return res;
        })
        .catch(() => caches.match(req).then((cached) => cached || caches.match("./index.html")))
    );
    return;
  }

  // Cache-first ለ static assets (icons, logo, manifest)
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
        return res;
      }).catch(() => cached);
    })
  );
});
